If you are developing DataX Plugin, In your Plugin you can use this directory to store temporary resources .

NOTE:
Each time install DataX, this directory will be cleaned up !