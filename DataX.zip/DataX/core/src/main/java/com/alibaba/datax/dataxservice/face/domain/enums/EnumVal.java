package com.alibaba.datax.dataxservice.face.domain.enums;

public interface EnumVal {
    public int value();
}