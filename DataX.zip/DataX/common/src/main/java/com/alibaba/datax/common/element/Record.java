package com.alibaba.datax.common.element;

/**
 * Created by jingxing on 14-8-24.
 * 代表传输的每一条数据
 */

public interface Record {

	public void addColumn(Column column);

	public void setColumn(int i, final Column column);

	public Column getColumn(int i);

	public String toString();

	public int getColumnNumber();

	public int getByteSize();

	public int getMemorySize();

}
