package com.alibaba.datax.common.plugin;


/**
 * 这里只是一个标示类
 * */
public interface PluginCollector {

}
