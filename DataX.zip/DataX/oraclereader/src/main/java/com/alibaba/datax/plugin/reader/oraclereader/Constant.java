package com.alibaba.datax.plugin.reader.oraclereader;

public class Constant {

    public static final int DEFAULT_FETCH_SIZE = 1024;

}
